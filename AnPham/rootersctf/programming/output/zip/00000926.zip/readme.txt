there is a file input.txt which contains 2 strings. and the longest common subsequence of those 2 strings will give you the flag
